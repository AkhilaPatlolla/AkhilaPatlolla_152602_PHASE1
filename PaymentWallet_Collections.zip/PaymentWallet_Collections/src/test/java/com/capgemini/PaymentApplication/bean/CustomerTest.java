package com.capgemini.PaymentApplication.bean;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	Customer cust = new Customer();

	public void testGetUserName() {
		cust.setUserName("akhila@1206");
		assertEquals("akhila@1206",cust.getUserName());
	}



	public void testGetPassword() {
		cust.setPassword("akki@1206");
		assertEquals("akki@1206",cust.getPassword());
		
	}


	public void testGetFirstName() {
		cust.setFirstName("akhila");
		assertEquals("akhila", cust.getFirstName());
		assertTrue("akhila".equalsIgnoreCase(cust.getFirstName()));
		assertNotNull(cust);
	}

	

	public void testGetLastName() {
		cust.setLastName("patlolla");
		assertEquals("patlolla", cust.getLastName());
		assertTrue("patlolla".equalsIgnoreCase(cust.getLastName()));
		assertNotNull(cust);
	}

	

	public void testGetGender() {
		cust.setGender("female");
		assertFalse("male".equalsIgnoreCase(cust.getGender()));
		assertTrue("female".equalsIgnoreCase(cust.getGender()));
	}

	

	public void testGetContact() {
		cust.setContact("9010009109");
		assertFalse("9010009109".equals(cust.getContact()));
		assertTrue("9010009109".equals(cust.getContact()));
	}

	

	public void testGetEmail() {
		cust.setEmail("akhila@gmail.com");
		assertEquals("akhila@gmail.com",cust.getEmail());
	
	}



	public void testGetAge() {
		cust.setAge(23);
		assertEquals(23, cust.getAge());
	}

	
	public void testGetAadharNo() {
		cust.setAadharNo("1235467890");
		assertTrue("1235467890".equals(cust.getAadharNo()));
		assertFalse("1246467890".equals(cust.getAadharNo()));
		
	}

	

	

}
